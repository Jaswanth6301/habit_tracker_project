const express = require('express');
const { PrismaClient } = require('@prisma/client');
const cors = require('cors');

const app = express();
const prisma = new PrismaClient();

app.use(cors());
app.use(express.json());

app.get('/habits', async (req, res) => {
  const habits = await prisma.habit.findMany();
  res.json(habits);
});

app.post('/habits', async (req, res) => {
  const { name } = req.body;
  const newHabit = await prisma.habit.create({
    data: { name },
  });
  res.json(newHabit);
});

app.listen(3001, () => {
  console.log('Backend running on http://localhost:3001');
});
